# Redis ORM Cache - Odoo 19 Quick Reference

## Installation (5 minutes)

```bash
# 1. Install Redis package
pip install redis

# 2. Copy module to Odoo addons
cp -r open_redis_ormcache /path/to/odoo/addons/

# 3. Add to odoo.conf
echo "ormcache_redis_url = redis://localhost:6379/0" >> /etc/odoo/odoo.conf

# 4. Restart Odoo
systemctl restart odoo

# 5. Install from Apps → Update Apps List → Redis ORM Cache → Install
```

## Configuration Examples

### Minimal Configuration
```ini
[options]
ormcache_redis_url = redis://localhost:6379/0
```

### With Custom TTL (1 day)
```ini
[options]
ormcache_redis_url = redis://localhost:6379/0
ormcache_redis_expire = 86400
```

### Remote Redis Server
```ini
[options]
ormcache_redis_url = redis://redis-server.example.com:6379/0
```

### With Authentication
```ini
[options]
ormcache_redis_url = redis://:mypassword@localhost:6379/0
```

## Verification Commands

```bash
# Check Redis is running
redis-cli ping
# Expected response: PONG

# Check cache size
redis-cli DBSIZE

# Monitor cache in real-time
redis-cli MONITOR

# Clear all cache
redis-cli FLUSHDB

# Check memory usage
redis-cli INFO memory

# View cache keys
redis-cli KEYS "*"
```

## Odoo Log Verification

```bash
# Check if module loaded successfully
grep "Redis ORM cache successfully registered" /var/log/odoo/odoo.log

# Check initialization
grep "Redis ORM cache initialized" /var/log/odoo/odoo.log

# Check for errors
grep -i "redis.*error" /var/log/odoo/odoo.log
```

## Performance Monitoring

```bash
# Monitor Redis stats
watch redis-cli INFO stats

# Track memory growth
watch redis-cli INFO memory

# Monitor connections
redis-cli MONITOR | grep -i "get\|set"
```

## Common Issues & Fixes

| Issue | Solution |
|-------|----------|
| Connection refused | Check Redis is running: `redis-cli ping` |
| Config not loaded | Verify `odoo.conf` syntax, restart Odoo |
| Module not installed | Update Apps List, then Install |
| Memory issues | Increase Redis `maxmemory` or reduce TTL |
| Slow cache | Check Redis performance: `redis-cli --latency` |

## File Structure

```
open_redis_ormcache/
├── __init__.py
├── __manifest__.py
├── modules/
│   ├── __init__.py
│   └── registry.py          # Main patch file
├── tools/
│   ├── __init__.py
│   └── RedisLRU.py          # Cache implementation
└── static/
    └── description/
        ├── icon.png
        └── index.html
```

## Configuration Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `ormcache_redis_url` | Required | Redis connection URL |
| `ormcache_redis_expire` | 604800 | Cache TTL in seconds (7 days) |

## TTL Quick Reference

| Time | Seconds |
|------|---------|
| 1 hour | 3600 |
| 6 hours | 21600 |
| 1 day | 86400 |
| 7 days | 604800 |
| 30 days | 2592000 |

## Multi-Server Configuration

### Master Server
```ini
[options]
ormcache_redis_url = redis://redis-ip:6379/0
max_cron_threads = 2
```

### Slave Server
```ini
[options]
ormcache_redis_url = redis://redis-ip:6379/0
max_cron_threads = 0
```

## Backup & Restore

```bash
# Backup Redis
redis-cli --rdb /path/to/backup.rdb

# Restore Redis
cp /path/to/backup.rdb /var/lib/redis/dump.rdb
redis-cli SHUTDOWN
redis-server

# Clear cache
redis-cli FLUSHDB
redis-cli SHUTDOWN
```

## Troubleshooting Flow

1. **Is Odoo running?**
   ```bash
   systemctl status odoo
   ```

2. **Is Redis running?**
   ```bash
   redis-cli ping
   ```

3. **Is module installed?**
   - Check in Odoo Apps → Installed Apps

4. **Check Odoo logs**
   ```bash
   tail -n 100 /var/log/odoo/odoo.log | grep -i redis
   ```

5. **Check Redis connectivity**
   ```bash
   redis-cli -h <host> -p <port> ping
   ```

6. **Clear cache and restart**
   ```bash
   redis-cli FLUSHDB
   systemctl restart odoo
   ```

## Performance Tips

1. **Tune TTL**: Shorter for high-traffic (86400), longer for stable (2592000)
2. **Monitor Memory**: Set `maxmemory 2gb` and `maxmemory-policy allkeys-lru`
3. **Use Persistence**: Enable Redis AOF for data safety
4. **Scale Horizontally**: Use multiple Odoo instances with shared Redis
5. **Monitor Latency**: `redis-cli --latency-history`

## Version Information

- **Module Version**: 19.0.1.0
- **Odoo Target**: 19.0 Community Edition
- **Python**: 3.10+
- **Redis**: 4.0+
- **redis-py**: 4.0+

## Emergency Procedures

### Redis Down - Fallback to In-Memory Cache
```bash
# Odoo automatically falls back if Redis unavailable
# Check logs to confirm:
grep "Falling back to in-memory cache" /var/log/odoo/odoo.log
```

### Clear Cache Corrupted
```bash
redis-cli FLUSHDB
systemctl restart odoo
```

### Reset to Default Caching
```bash
# Temporarily: Comment out ormcache_redis_url in odoo.conf
# Then restart Odoo
```

## Useful Commands

```bash
# Show current config
odoo --help | grep -i cache

# Check module dependencies
grep -r "depends" /path/to/odoo/addons/open_redis_ormcache/

# View installed modules
sqlite3 /path/to/odoo/data/database.db "SELECT name FROM ir_module_module WHERE state='installed';"
```

## Additional Resources

- Redis Documentation: https://redis.io/docs/
- Odoo Documentation: https://www.odoo.com/documentation/
- redis-py Documentation: https://redis-py.readthedocs.io/

## Support Contacts

For module-specific issues:
1. Check module logs in Odoo
2. Review this quick reference
3. Consult UPGRADE_GUIDE.md for detailed information
4. Check system logs: `/var/log/odoo/odoo.log`

---

**Created**: April 2026  
**Version**: 19.0.1.0  
**Status**: Ready for Production
