# Redis ORM Cache - Odoo 19 Upgrade Guide

## Overview

This document provides a complete guide for upgrading the Redis ORM Cache module from Odoo 18 to Odoo 19 Community Edition.

## Key Changes Made

### 1. **Version Updates**
- **Manifest Version**: Changed from `18.0.2.0` to `19.0.1.0`
- **Module Documentation**: Updated all references from Odoo 18 to Odoo 19
- **Python Support**: Updated for Odoo 19's Python requirements

### 2. **Import Path Compatibility**
- Module maintains compatibility with Odoo 19's registry structure
- All imports from `odoo.tools.config` and `odoo.modules.registry` remain valid in Odoo 19
- No breaking changes in the Registry API between Odoo 18 and 19

### 3. **Enhanced Error Handling**
- Added more robust error handling in `registry.py`
- Per-cache error handling to prevent entire cache initialization failure
- Improved logging with `exc_info=True` for better debugging
- Graceful fallback to original cache if RedisLRU initialization fails

### 4. **Redis Client Compatibility**
- Maintained backward compatibility with various Redis client versions
- Enhanced detection logic for Redis client class availability
- Support for both modern and legacy redis-py versions

### 5. **Code Quality Improvements**
- Better exception handling with detailed logging
- Improved variable naming and code documentation
- Thread-safe cache access patterns
- Enhanced cache generation tracking

## Installation Steps

### Prerequisites
```bash
# Install Python Redis library
pip install redis

# Ensure Odoo 19 is installed
pip install odoo==19.0 # or use your distribution method
```

### Setup Instructions

1. **Copy the module** to your Odoo addons directory:
```bash
cp -r open_redis_ormcache_19 /path/to/odoo/addons/open_redis_ormcache
# or rename the folder to remove the _19 suffix
```

2. **Configure Odoo** in your `odoo.conf` file:
```ini
[options]
# Required: Redis connection URL
ormcache_redis_url = redis://localhost:6379/0

# Optional: Cache expiration time in seconds (default: 7 days = 604800 seconds)
ormcache_redis_expire = 604800
```

3. **Restart your Odoo server**:
```bash
systemctl restart odoo
# or manually restart your Odoo service
```

4. **Install the module**:
- Navigate to Apps → Update Apps List
- Search for "Redis ORM Cache"
- Click Install

5. **Verify installation**:
Check Odoo logs for confirmation message:
```
Redis ORM cache successfully registered for Odoo 19
Redis ORM cache initialized for database '<db_name>' with TTL 604800s
```

## Configuration Options

### Basic Configuration
```ini
[options]
ormcache_redis_url = redis://localhost:6379/0
```

### With Authentication
```ini
[options]
ormcache_redis_url = redis://:password@localhost:6379/0
```

### With Custom TTL
```ini
[options]
ormcache_redis_url = redis://localhost:6379/0
ormcache_redis_expire = 86400  # 1 day
```

### For Multi-Database Setup
```ini
[options]
ormcache_redis_url = redis://localhost:6379/0
# Database 0 for production, Database 1 for testing, etc.
```

## Multi-Server Setup (Master-Slave Configuration)

### Master Server Configuration
```ini
[options]
ormcache_redis_url = redis://redis-server-ip:6379/0
max_cron_threads = 2  # Must be > 1 for master
workers = 4
```

### Slave Server Configuration
```ini
[options]
ormcache_redis_url = redis://redis-server-ip:6379/0  # Same Redis as master
max_cron_threads = 0  # Must be 0 for slaves
```

### NFS Configuration (for Master-Slave)
```ini
[options]
data_dir = /mnt/nfs/odoo_data
```

## Differences from Odoo 18

| Aspect | Odoo 18 | Odoo 19 |
|--------|---------|---------|
| Version Number | 18.0.2.0 | 19.0.1.0 |
| Registry API | Unchanged | Unchanged |
| Config System | Unchanged | Unchanged |
| Redis Client Support | Limited | Enhanced |
| Error Handling | Basic | Robust |
| Logging | Standard | Enhanced |
| Python Version | 3.9+ | 3.10+ |

## Troubleshooting

### Issue: "ormcache_redis_url not configured"
**Solution**: Ensure `ormcache_redis_url` is set in your `odoo.conf` file and Odoo has been restarted.

### Issue: "Redis connection failed"
**Solution**: 
- Verify Redis is running: `redis-cli ping`
- Check Redis URL is correct: `redis://localhost:6379/0`
- Verify network connectivity between Odoo and Redis server
- Check Redis firewall rules

### Issue: "redis module not found"
**Solution**:
```bash
pip install redis
# or for the user running Odoo
sudo -u odoo pip install redis
```

### Issue: "UnpicklingError in cache operations"
**Solution**:
- Clear Redis cache: `redis-cli FLUSHDB`
- Restart Odoo server
- This usually occurs after major code changes

### Issue: "Cache initialization failed for specific cache"
**Solution**:
- Check logs for specific cache name that failed
- Verify Redis has sufficient memory
- Monitor Redis memory usage: `redis-cli INFO memory`

## Performance Tuning

### Redis Memory Optimization
```bash
# Check current memory usage
redis-cli INFO memory

# Set max memory policy (in redis.conf)
maxmemory 2gb
maxmemory-policy allkeys-lru
```

### Cache TTL Tuning
```ini
[options]
# Shorter TTL for high-traffic systems (1 day)
ormcache_redis_expire = 86400

# Longer TTL for stable systems (30 days)
ormcache_redis_expire = 2592000
```

### Worker Configuration
```ini
[options]
# For better performance with Redis caching
workers = 4
max_cron_threads = 2
```

## Migration from Odoo 18 to 19

### Step-by-Step Migration

1. **Backup your database**:
```bash
pg_dump odoo_db > odoo_db_backup.sql
```

2. **Stop Odoo 18 server**:
```bash
systemctl stop odoo18
```

3. **Update the module folder**:
```bash
# Remove old module
rm -rf /path/to/odoo18/addons/open_redis_ormcache

# Copy new module
cp -r open_redis_ormcache_19 /path/to/odoo19/addons/open_redis_ormcache
```

4. **Update configuration** in your new Odoo 19 `odoo.conf`:
```ini
[options]
ormcache_redis_url = redis://localhost:6379/0
ormcache_redis_expire = 604800
```

5. **Clear Redis cache** (important for compatibility):
```bash
redis-cli FLUSHDB
```

6. **Start Odoo 19**:
```bash
systemctl start odoo19
```

7. **Run Odoo upgrade**:
```bash
odoo --upgrade open_redis_ormcache --stop-after-init
```

8. **Verify installation**:
- Check logs for success message
- Navigate to Apps → Installed Apps and confirm module is active

## Monitoring

### Check Redis Cache Statistics
```bash
# Connect to Redis
redis-cli

# Get all cache keys
KEYS "*"

# Get specific database cache size
DBSIZE

# Monitor cache operations in real-time
MONITOR
```

### Odoo Log Monitoring
```bash
# Watch Odoo logs for cache operations
tail -f /var/log/odoo/odoo.log | grep "redis\|cache"

# Search for errors
grep -i "redis.*error" /var/log/odoo/odoo.log
```

## Features

✅ **High Performance**: Redis-backed caching for improved performance  
✅ **Horizontal Scaling**: Share cache across multiple Odoo instances  
✅ **Configurable TTL**: Set custom cache expiration times  
✅ **Graceful Fallback**: Automatically falls back to in-memory cache if Redis unavailable  
✅ **Thread-Safe**: Safe for concurrent access  
✅ **Generation Tracking**: Smart cache invalidation with generation counters  
✅ **Robust Error Handling**: Detailed logging for troubleshooting  

## Support

For issues, questions, or contributions:
- Check logs in `/var/log/odoo/odoo.log`
- Verify Redis connectivity: `redis-cli ping`
- Review configuration: Check `odoo.conf` settings
- Test cache operations manually in Odoo shell

## License

OPL-1 (Odoo Proprietary License)

## Version History

### Version 19.0.1.0 (Current)
- Upgrade for Odoo 19 Community Edition
- Enhanced error handling
- Improved logging
- Better Redis client compatibility

### Version 18.0.2.0 (Previous)
- Original Odoo 18 implementation
- Basic Redis caching
- Standard error handling

---

**Last Updated**: April 2026  
**Odoo Version**: 19.0  
**Python Version**: 3.10+  
**Redis Version**: 4.0+
